import argparse
import model_management

import torch
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import torch.nn.functional as F
from torchvision import datasets, transforms, models
from PIL import Image
from torch import nn
from torch import optim
import train


ap = argparse.ArgumentParser(
    description='predict-file')
ap.add_argument('input_img', default='paind-project/flowers/test/1/image_06743.jpg', nargs='*', action="store", type = str)
ap.add_argument('checkpoint', default='/home/workspace/paind-project/model_challenge_2.pth', nargs='*', action="store",type = str)
ap.add_argument('--top_k', default=5, dest="top_k", action="store", type=int)
ap.add_argument('--category_names', dest="category_names", action="store", default='cat_to_name.json')

pa = ap.parse_args()
path_image = pa.input_img
number_of_outputs = pa.top_k
input_img = pa.input_img
path = pa.checkpoint

def load_checkpoint(path="model_challenge_2.pt"):
    """
    Loads deep learning model checkpoint.
    """
    
    checkpoint = torch.load('checkpoint.pth')
    dropout = checkpoint['dropout']
    model = fun_model_setup(dropout)
    model.class_to_idx = checkpoint['class_to_idx']
    model.load_state_dict(checkpoint['state_dict'])
    
    return model



def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    
    # TODO: Process a PIL image for use in a PyTorch model
    image = Image.open(image)
    
    # Note: For me the simplest way was to just use the already defined transformation 
    return test_transform(image)


def imshow(image, ax=None, title=None):
    """Imshow for Tensor."""
    if ax is None:
        fig, ax = plt.subplots()
    
    # PyTorch tensors assume the color channel is the first dimension
    # but matplotlib assumes is the third dimension
    image = image.numpy().transpose((1, 2, 0))
    
    # Undo preprocessing
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = std * image + mean
    
    # Image needs to be clipped between 0 and 1 or it looks like noise when displayed
    image = np.clip(image, 0, 1)
    
    ax.imshow(image)
    
    return ax


def predict(image_path, model, topk=5):   
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    
    # TODO: Implement the code to predict the class from an image fill
    model.eval()
    with torch.no_grad():
        logps = model.forward(process_image(image_path).unsqueeze(0))
        ps = torch.exp(logps)
        probs, labels = ps.topk(topk, dim=1)
        
        class_to_idx_inv = {model.class_to_idx[i]: i for i in model.class_to_idx}
        classes = list()
    
        for label in labels.numpy()[0]:
            classes.append(class_to_idx_inv[label])
        
        return probs.numpy()[0], classes



model = load_checkpoints(path)

with open('cat_to_name.json', 'r') as json_file:
    cat_to_name = json.load(json_file)
    
   
image_class = '1'

predict_probs, predict_classes = predict(image_path, model)

classes = []
for predict_class in predict_classes:
    classes.append(cat_to_name[predict_class])

fig = plt.figure(figsize = (12,10))

# Plotting Image
ax = plt.subplot(2,1,1)
ax.set_title(cat_to_name[image_class])
plt.axis('off')
imshow(process_image(image_path), ax, title="lol");

# Plotting probabilities
plt.subplot(2,1,2)
sns.barplot(x=predict_probs, y=classes, color='cornflowerblue');
plt.show()