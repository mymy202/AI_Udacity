import argparse

import torch
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import torch.nn.functional as F
from torchvision import datasets, transforms, models
from PIL import Image
from torch import nn
from torch import optim



def load_data(args = "./flowers" ):
    data_dir = args
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'
    
    # TODO: Define your transforms for the training, validation, and testing sets
    # data_transforms = 
    train_transform = transforms.Compose([transforms.RandomRotation(50),
                                            transforms.RandomResizedCrop(224),
                                            transforms.RandomHorizontalFlip(),
                                            transforms.ToTensor(),
                                            transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])]
                                        )

    valid_transform = transforms.Compose([transforms.Resize(255),
                                            transforms.CenterCrop(224),
                                            transforms.ToTensor(),
                                            transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])]
                                        )

    test_transform = transforms.Compose([transforms.Resize(255),
                                            transforms.CenterCrop(224),
                                            transforms.ToTensor(),
                                            transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])]
                                        )

    # TODO: Load the datasets with ImageFolder
    # image_datasets = 
    train_data = datasets.ImageFolder(train_dir, transform = train_transform)
    valid_data = datasets.ImageFolder(valid_dir, transform = valid_transform)
    test_data = datasets.ImageFolder(test_dir, transform = test_transform)

    # TODO: Using the image datasets and the trainforms, define the dataloaders
    # dataloaders =
    train_loader = torch.utils.data.DataLoader(train_data, batch_size = 64, shuffle = True)
    valid_loader = torch.utils.data.DataLoader(valid_data, batch_size = 64)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size = 64)
    
    return train_data, train_loader, valid_loader, test_loader





def fun_model_setup(dropout=0.5):
    
    model = models.vgg16(pretrained=True)  

    # Freeze parameters so we don't backprop through them
    for param in model.parameters():
        param.requires_grad = False

    from collections import OrderedDict
    classifier = nn.Sequential(OrderedDict([
                                  ('dropout',nn.Dropout(dropout)),
                                  ('inputs', nn.Linear(25088, 110)),
                                  ('relu1', nn.ReLU()),
                                  ('hidden_layer_1', nn.Linear(110, 100)),
                                  ('relu2',nn.ReLU()),
                                  ('hidden_layer_2',nn.Linear(100, 90)),
                                  ('relu3',nn.ReLU()),
                                  ('hidden_layer_3',nn.Linear(90, 102)),
                                  ('output', nn.LogSoftmax(dim=1))
                              ]))


    model.classifier = classifier

    return model

def train_network(model, epochs, print_every, steps, train_loader, valid_loader):
    # Get device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr=0.002 )
    model.to(device)

    print_every = 10 # every 10 batches
    steps = 0

    train_loss, validation_loss = [], []
    for e in range(epochs):
        item_running_loss = 0

        for ii, (inputs, labels) in enumerate(train_loader):
            steps += 1

            # Move input and label tensors to the GPU (if available)
            inputs, labels = inputs.to(device), labels.to(device)

            optimizer.zero_grad()

            # Forward and backward passes
            outputs = model.forward(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            item_running_loss += loss.item()

            if steps % print_every == 0:
                # Deactivate dropout
                model.eval()
                item_validation_loss = 0
                accuracy = 0

                for ii, (validation_inputs, validation_labels) in enumerate(valid_loader):
                    optimizer.zero_grad()

                    # We will keep using the training hardware for validation (cuda or cpu)
                    validation_inputs, validation_labels = validation_inputs.to(device), validation_labels.to(device)
                    model.to(device)

                    with torch.no_grad():    
                        outputs = model.forward(validation_inputs)
                        item_validation_loss = criterion(outputs, validation_labels)
                        ps = torch.exp(outputs).data 
                        equality = (validation_labels.data == ps.max(1)[1])
                        accuracy += equality.type_as(torch.FloatTensor()).mean()

                item_validation_loss = item_validation_loss / len(valid_loader)
                item_train_loss = item_running_loss / len(train_loader)

                train_loss.append(item_train_loss)
                validation_loss.append(item_validation_loss)

                accuracy = accuracy /len(valid_loader)

                print("Epoch: {}/{}... ".format(e+1, epochs),
                      "Loss: {:.4f}".format(item_running_loss/print_every),
                      "Validation Loss {:.4f}".format(item_validation_loss),
                      "Accuracy: {:.4f}".format(accuracy))

                item_running_loss = 0

                
                
parser = argparse.ArgumentParser(description='Training a neural network on a given dataset')
parser.add_argument('data_directory', help='Path to dataset on which the neural network should be trained on')
parser.add_argument('--save_dir', help='Path to directory where the checkpoint should be saved')
parser.add_argument('--arch', help='Network architecture (default \'vgg16\')')
parser.add_argument('--learning_rate', help='Learning rate')
parser.add_argument('--hidden_units', help='Number of hidden units')
parser.add_argument('--epochs', help='Number of epochs')
parser.add_argument('--gpu', help='Use GPU for training', action='store_true')


args = parser.parse_args()


save_dir = '' if args.save_dir is None else args.save_dir
network_architecture = 'vgg16' if args.arch is None else args.arch
learning_rate = 0.0025 if args.learning_rate is None else int(args.learning_rate)
hidden_units = 512 if args.hidden_units is None else float(args.hidden_units)
epochs = 8 if args.epochs is None else int(args.epochs)
print_every = 10 # every 10 batches
steps = 0

train_data, train_loader, valid_loader, test_loader = load_data(args.data_directory)

model = fun_model_setup(dropout=0.5)
model.class_to_idx = train_data.class_to_idx

train_network(model, epochs, print_every, steps, train_loader, valid_loader)
